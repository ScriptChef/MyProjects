<?php
include 'adminchecklogin.php';
// Check if the administrator is logged in first, then redirect 
// to the admin login page.
if ($_SESSION['username']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>

<?php 

include 'adminchecklogin.php';

// Destroy administrators session.
session_destroy();

?>

