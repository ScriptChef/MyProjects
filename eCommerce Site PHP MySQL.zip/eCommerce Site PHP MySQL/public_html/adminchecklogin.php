<?php

// Start a session
session_start();

if (!isset($_SESSION['admin']) || !isset($_SESSION['password'])) {
	$logged_in = 0;
	return;
} else {

	// $_SESSION['password'] will be encrypted.

	if(!get_magic_quotes_gpc()) {
		$_SESSION['admin'] = addslashes($_SESSION['admin']);
	}


	// Add slashes to Session admin before using in a query.
	$pass = $db_object->query("SELECT password FROM users WHERE admin = '".$_SESSION['admin']."'");

	if(DB::isError($pass)) {
		$logged_in = 0;
		unset($_SESSION['admin']);
		unset($_SESSION['password']);
		// Destroy incorrect session variables.
	}

	$db_pass = $pass->fetchRow();

	// Now we have encrypted password from the database in 
	// $db_pass['password'], stripslashes() just in case:
 
	$db_pass['password'] = stripslashes($db_pass['password']);
	$_SESSION['password'] = stripslashes($_SESSION['password']);

	// Compare the passwords

	if($_SESSION['password'] == $db_pass['password']) { 
		// Valid password for table admin.
		$logged_in = 1;
	} else {
		$logged_in = 0;
		unset($_SESSION['admin']);
		unset($_SESSION['password']);
		// Destroy incorrect session variables.
	}
}

// Clear session variable password.
unset($db_pass['password']);

$_SESSION['admin'] = stripslashes($_SESSION['admin']);

?>