<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Update Item</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style7 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
.style8 {font-size: x-large}
-->
</style>
 
</head>
<h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style7">Shop-o-holic</span></h1>
<body>
<span class="style15 style8">Update Item</span> <br>
<br>
<?php

// Get item number from previous page.
$itemno = $_POST['itemno'];

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Define the query.  Get all info about this item.
$sql="select * from item where id=$itemno";
 
// Execute the query.
$rs2=mysql_query($sql,$conn) 
		or die("Could not execute query");

while( $row = mysql_fetch_array($rs2) )
{
	$id=$row["id"]; 
	$brand=$row["brand"]; 
	$name=$row["name"]; 
	$price=$row["price"];
	$stocklevel=$row["stocklevel"];
	$reorderlevel=$row["reorderlevel"];
	$reorderquantity=$row["reorderquantity"];
	$type=$row["type"];
	$size=$row["size"];
	$info=$row["info"];

}

// Display all info into the form below, for admin to edit. 
// When admin has finished editing, go to 'update_item3.php'.

echo("<form action=update_item3.php method=post>
ID: <input type=text name=id size=3 value=$id><br>
Product Title: <input type=text name=\"newname\" size=50 value=\"$name\"><br>
Price: <input type=text name=newprice size=8 value=$price><br>
Stock Level: <input type=text name=newstocklevel size=3 value=$stocklevel><br>
Reorder Level: <input type=text name=newreorderlevel size=3 value=$reorderlevel><br>
Reorder Quantity: <input type=text name=newreorderquantity size=3 value=$reorderquantity><br>
Type(Category): <input type=text name=newtype size=1 value=$type><br>
Brand: <input type=text name=\"newbrand\" size=25 value=\"$brand\"><br>
Sizes Available: <input type=text name=\"newsize\" size=50 value=\"$size\"><br>
Description: <input type=textarea name=\"newinfo\" size=100 value=\"$info\"><br><br>
<input type=submit value=Submit>
<input type=reset value=Reset>
</form>");

?>

<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>