<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - View Users</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style15 {font-size: x-large}
.style16 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
-->
</style>
</head>
<body> 
 <h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style16">Shop-o-holic</span></h1>
  
  <span class="style15">Registered Users</span> <br>
  <br>

<?php

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';
 
// Define the query: Retrieve all users details from the table 'users'.
$sql="select * from users";
 
// Execute this query.
$rs=mysql_query($sql,$conn) 
		or die("Could not execute query");

// Put the users details into a table.
$list = "<table border=\"1\" cellpadding=\"2\">";
$list.="<tr><th>User ID</th>";
$list.="<th>First Name</th>";
$list.="<th>Last Name</th>";
$list.="<th>User Name</th>";
$list.="<th>Email Address</th>";
$list.="<th>Encrypted Password</th></tr>";

// While there are more users to get, display a users details.
while($row= mysql_fetch_array($rs) )
{
   $list .= "<tr>";
   $list .= "<td>".$row["userid"]."</td>";
   $list .= "<td>".$row["first_name"]."</td>";
   $list .= "<td>".$row["last_name"]."</td>";
   $list .= "<td>".$row["username"]."</td>";
   $list .= "<td>".$row["email"]."</td>";
   $list .= "<td>".$row["password"]."</td>";
   $list .= "</tr>";
}
$list .= "</table>";
echo($list);
?>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>
