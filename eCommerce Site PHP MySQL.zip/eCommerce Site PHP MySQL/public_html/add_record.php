<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Add an Item</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style10 {color: #334d55}
.style11 {
	font-size: x-large;
	font-family: Arial, Helvetica, sans-serif;
	color: #FFFFFF;
}
.style12 {font-size: x-large}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}

function MM_displayStatusMsg(msgStr) { //v1.0
  status=msgStr;
  document.MM_returnValue = true;
}
//-->
</script>
</head>
<body>
<h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11">Shop-o-holic</span></h1>
<html><head>
<title>Add an Item</title></head>
<body>
<span class="style14 style12">Add a New Item</span><br><br>
<form action="<?php echo($PHP_SELF); ?>" method="post">
Product Title: <input type="text" name="name" size="50"><br>
Price: <input type="text" name="price" size="8"><br>
Stock Level: <input type="text" name="stocklevel" size="3"><br>
Reorder Level: <input type="text" name="reorderlevel" size="3"><br>
Reorder Quantity: <input type="text" name="reorderquantity" size="3"><br>
Type(Category): <input type="text" name="type" size="1"><br>
Brand: <input type="text" name="brand" size="25"><br>
Sizes Available: <input type="text" name="size" size="50"><br>
Description: <input type="textarea" name="info" size="100"><br><br>
<input type="submit" value="Submit">
<input type="reset" value="Reset">
</form>

<?php
// HTML add record form defined above.

// If all fields have been completed.
if($name and $price and $stocklevel and $reorderlevel and $reorderquantity 
and $type and $brand and $size and $info)
{

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Create the query: Insert new record with all fields into the table 'item'.
$sql="insert into item (name, price, stocklevel, reorderlevel, reorderquantity, 
type, brand, size, info) values ( \"$name\", \"$price\", \"$stocklevel\" , \"$reorderlevel\", 
\"$reorderquantity\", \"$type\", \"$brand\", \"$size\", \"$info\")";

// Execute the query
$rs=mysql_query($sql,$conn);
if($rs){
echo("Record added:$name $price $stocklevel $reorderlevel $reorderquantity $type $brand $size");
}
}
?>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body></html> 
</body></html>
