<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Shopoholic Online</title>
<style type="text/css">
<!--
.style1 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
</head>

<body> 

<?php 

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Define the SQL query.
$sql="select brand,id,name,price,type,size from item where id=$ids";

// Execute this query.
$rs=mysql_query($sql,$conn);

// Get information about the item.
while( $row = mysql_fetch_array($rs) )
{
	$id=$row["id"]; 
	$brand=$row["brand"]; 
	$name=$row["name"]; 
	$price=$row["price"];
	$size=$row["size"];
}

// Display the image.
echo("<p><img src=$id.jpg align=center /></p>");

// JavaScript 'close window' link.
echo("<p align=center><a href=javascript:self.close() class=style1>Close Window</a></p>");

?>

</body>
</html>
