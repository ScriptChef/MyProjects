<?
$dbhost = 'achilles';  // Define server name.
$dbusername = 'mzh2';  // Define MySQL username.
$dbpasswd = 'Ahcoh6ti';   // Define MySQL password.
$database_name = 'mzh2';  // Define the database name.

// Make the connection to MySQL.
$connection = mysql_pconnect("$dbhost","$dbusername","$dbpasswd")
	or die ("Couldn't connect to server.");

// Select the database.
$db = mysql_select_db("$database_name", $connection)
	or die("Couldn't select database.");
?>