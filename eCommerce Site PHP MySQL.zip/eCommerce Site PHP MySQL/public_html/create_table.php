<?php

include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Create Table</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style10 {font-size: x-large}
.style11 {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
}
-->
</style>
</head>
<body> 
 <h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11">Shop-o-holic</span></h1>
 <span class="style10">Create a Table </span><br>
 <br>

<?php

// To create a table, first we have to specify the number of fields below.
if(!$fields and !$db)
{
  $form ="<form action=\"$PHP_SELF\" method=\"post\">";
  $form.="How many fields are needed in the new table?  ";
  $form.="<input type=\"text\" name=\"fields\" size=\"5\"><br><br>";
  $form.="<input type=\"submit\" value=\"Submit\">";
  echo($form);
}
else if( !$db )
{ 
  // Create a form where table fields and their types can be defined.
  $form ="<form action=\"$PHP_SELF\" method=\"post\">";
  $form.="Database: &nbsp;&nbsp;&nbsp;&nbsp;<input type=\"text\" name=\"db\"><br>";
  $form.="Table Name: &nbsp;<input type=\"text\" name=\"table\" size=\"10\"><br> ";
  for ($i = 0 ; $i <$fields; $i++) 
  {
    $form.="Column Name:<input type=\"text\" name=\"name[$i]\" size=\"10\"> ";
    $form.="Type: <select name=\"type[$i]\">";
    $form.="<option value=\"char\">char</option>";	
    $form.="<option value=\"varchar\">varchar</option>";
    $form.="<option value=\"int\">int</option>";
    $form.="<option value=\"float\">float</option>";
    $form.="<option value=\"timestamp\">timestamp</option>";
    $form.="</select> ";
    $form.="Size:<input type=\"text\" name=\"size[$i]\" size=\"5\"><br>";
  }
  $form.=" <input type=\"submit\" value=\"Submit\"></form>";
  echo($form);
}
else
{
  // Make a connection to MySQL with the server name, MySQL username and password defined below.
  $conn = @mysql_pconnect("achilles", "mzh2", "Ahcoh6ti")
	or die("Could not connect.");
  
  // Select the database as specified previously.
  $rs = @mysql_select_db($db, $conn)
	or die("Could not select database.");
	
  // Count the number of columns.
  $num_columns = count($name);
  
  // Create the table using a for loop.
  $sql = "create table $table (";
  for ($i = 0; $i < $num_columns; $i++) 
  {
    $sql .= "$name[$i] $type[$i]";
    if(($type[$i] =="char") or ($type[$i] =="varchar"))
    {
      if($size[$i] !="" ){ $sql.= "($size[$i])"; }
    }
    if(($i+1) != $num_columns){ $sql.=","; }
  }
  $sql .= ")";
  
  // MySQL's response to creating the table.
  echo("SQL COMMAND: $sql <hr>");

  $result = mysql_query($sql,$conn)
	or die("Could not execute SQL query");

  if ($result) {     
	echo("RESULT: table \"$table\" has been created");
  }
}
?>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>
