<?
/* Check User Script */
session_start();  // Start Session.

include 'db.php';
// Convert posted variables from the admin log-in form to simple variables.
$admin = $_POST['admin'];
$password = $_POST['password'];


// IF both username and password fields are not completed, prompt for entry of either field
// and reload the admin login form.
   if((!$admin) || (!$password)){
	echo "Please enter ALL of the information! <br />";
	include 'adminlogin_form.html';
	exit();
}

// Check if the login details validates in the database.
$sql = mysql_query("SELECT * FROM admin WHERE admin='$admin' AND password = \"$password\" ");
$login_check = mysql_num_rows($sql);

if($login_check > 0){
	while($row = mysql_fetch_array($sql)){
	foreach( $row AS $key => $val ){
		$$key = stripslashes( $val );
	}
		session_register('admin');
		$_SESSION['admin'] = $admin;
		
		mysql_query("UPDATE admin SET last_login=now() WHERE admin='$admin'");
		
		header("Location: admin.php");
	}
} else {

        // If login unsuccessful, due to incorrect username and/or password, reload the
        // admin login page.
	echo "You could not be logged in. Either the admin name and password do not match.<br />
	Please try again.<br />";
	include 'adminlogin_form.html';
}
?>