<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic Online Administration</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style7 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
.style9 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
}
.style10 {font-size: x-large}
-->
</style>
</head>
<h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style7">Shop-o-holic</span></h1>
<body>
<p align="center"><span class="style2"><span class="style9">Shopoholic Online Administration</span><br><br>
      <a href="add_record.php">Add an Item</a><br>
      <a href="create_table.php">Create a Table</a><br>
      <a href="delete_table.php">Delete a Table</a><br>
      <a href="adminlogout.php">Logout</a><br>
      <a href="remove_item.php">Remove Item</a><br>
      <a href="delete_order.php">Remove Order</a> <br>
      <a href="remove_user.php">Remove User</a> <br>
      <a href="uploadfiles.php">Upload Files</a><br>
      <a href="update_item1.php">Update Item</a><br>
      <a href="get_enquiry.php">View Enquiries</a> <br>
      <a href="get_feedback.php">View Feedback</a> <br>
      <a href="get_items.php">View Items</a> <br>
      <a href="get_orders.php">View Orders</a> <br>
      <a href="get_users.php">View Users</a> <br>
    </span><br>
</p>
</body>
</html>
