<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Upload Files To Server</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style15 {font-size: x-large}
.style16 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
-->
</style>
</head>
<body> 
 <h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style16">Shop-o-holic</span></h1>
  
   <span class="style15">Upload Files To Server</span> <br>
  <br>
<?php 	

// if the file exists, upload the file else give an error message.

if($file_name !="")
 {
  copy ("$file", "/var/autofs/home/s_home/mzh2/public_html/uploads/$file_name") or die("Could not copy file");
 }
else
 {
  die("No file specified");
 }

// Give user upload information about the file in the HTML code below.

?>

<html>
<head> <title>Upload complete</title> </head>
<body>
<h3>File upload succeeded...</h3>
<ul>
<li>Sent: <?php echo "$file_name"; ?>
<li>Size: <?php echo "$file_size"; ?> bytes
<li>Type: <?php echo "$file_type"; ?>
</ul>
</body>
</html>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>
