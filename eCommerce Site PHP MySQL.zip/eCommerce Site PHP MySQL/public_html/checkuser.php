<?
/* Check User Script */
session_start();  // Start Session

// Connect to the database using file 'db.php'.
include 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];

if((!$username) || (!$password)){
	echo "Please complete both fields.";
	include 'login_form.html';
	exit();
}

// Check if the user login is valid in the database.
$sql = mysql_query("SELECT * FROM users WHERE username='$username' AND password = password( \"$password\") ");
$login_check = mysql_num_rows($sql);

if($login_check > 0){
	while($row = mysql_fetch_array($sql)){
	foreach( $row AS $key => $val ){
		$$key = stripslashes( $val );
	}
		// Register these session variables for later use.
		session_register('first_name');
		$_SESSION['first_name'] = $first_name;
		session_register('last_name');
		$_SESSION['last_name'] = $last_name;
		session_register('username');
		$_SESSION['username'] = $username;
		session_register('special_user');
		$_SESSION['user_level'] = $user_level;
                session_register('userid');
                $_SESSION['userid'] = $userid;
		session_register('email');
                $_SESSION['email'] = $email;
		session_register('address');
                $_SESSION['address'] = $address;
		
		mysql_query("UPDATE users SET last_login=now() WHERE userid='$userid'");
		
		header("Location: login_success.php");
	}
} else {
        // Else, display error message and reload login page.
	echo "You could not be logged in. Either the username and password do not match.<br />
	Please try again.<br />";
	include 'login_form.html';
}
?>