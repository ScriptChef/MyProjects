<?php
include 'checklogin.php';
// ACCESS RESTRICTION
// Check if user is logged in, else redirect user to the login page
if ($_SESSION['username']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/login_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - My Account Details</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style11 {color: #006699}
a {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style14 {
	font-size: x-large;
	color: #000000;
}
.style15 {color: #000000}
-->
a:hover {color: #FF0000;}
.style20 {font-size: x-large; color: #FFFFFF; font-family: Arial, Helvetica, sans-serif; font-weight: bold;}
.style28 {
	font-size: medium;
	font-weight: bold;
}
</style>
<script language="JavaScript" type="text/JavaScript">
<!--

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}

function MM_jumpMenuGo(selName,targ,restore){ //v3.0
  var selObj = MM_findObj(selName); if (selObj) MM_jumpMenu(targ,selObj,restore);
}
//-->
</script>
</head>
<!-- The structure of this file is exactly the same as 2col_rightNav.html;
     the only difference between the two is the stylesheet they use -->
<body> 
<div class="style15" id="masthead">  
<span class ="gloss2">  <h1 class="style20" id="siteName">Shop-o-holic</h1></span>
  <div id="globalNav"> 
    <span class="style2"><a href="index.php">	Home</a> | <a href="login_form.html">Login</a> | <a href="register.php">Register</a> | <a href="userpage.php">My Account</a> | <a href="contact.php">Contact Us</a> | <a href="generalhelp.php">Help</a> | <a href="about.php">About</a></span></div> 
</div> 
<!-- end masthead --> 
<div id="content"> 

<p> <span class="style14">My Account Details</span></p>
<?php

// Get the users ID from the registered session.
$userid = $_SESSION['userid'];

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Create the query: Get all information about this user from the 'users' table.
$sql="select * from users where userid=$userid";
 
// Execute the query.
$rs=mysql_query($sql,$conn) 
		or die("You are not authorised to view this page. <br>Please log-in first.");

while( $row = mysql_fetch_array($rs) )
{
	$userid=$row["userid"]; 
	$first_name=$row["first_name"];
	$last_name=$row["last_name"];
	$username=$row["username"];
	$email=$row["email"];
	$address=$row["address"];
	$password=$row["password"];
 

// Display the users details using the 'echo' function.
echo("Username: $username<br><br>");
echo("Full Name: $first_name $last_name<br><br>");
echo("E-mail Address: $email<br><br>");
echo("Shipping Address: $address");
 
}

?>
<br><br><a href="javascript: history.go(-1)"><font face=Verdana, Arial, Helvetica, sans-serif> << </font></a>
</div>
<!--end content --> 
<div id="navBar"> 
  <div id="search"> 
    <form action="search.php"> 
      <label><span class="style2">search</span></label> 
      <span class="style2">
      <input type="text" name="search" size="10"> 
      <input type="submit" value="go"> 
      </span>
    </form> 
  </div> 
  <div id="sectionLinks"> 
    <ul class="style2">
<li><a href="mens.php">Mens</a></li>
<li><a href="womens.php">Womens</a></li>
<li><a href="childrens.php">Childrens</a></li>
<li><a href="footwear.php">Footwear</a></li>
<li><a href="accessories.php">Accessories</a></li>
    </ul> 
  </div>
  <div class="relatedLinks style2">
    <h3>Sort By Brand </h3> 
    <ul> 
      <li>
        <form name="form1" action="#">
          <select name="brandmenu" onChange="MM_jumpMenu('parent',this,0)">
		    <option value="#">Select Brand</option>
            <option value="brand.php?br=Adidas">Adidas</option>
            <option value="brand.php?br=Animal">Animal</option>
			<option value="brand.php?br=Ben Sherman">Ben Sherman</option>
			<option value="brand.php?br=Calvin Klein">Calvin Klein</option>
			<option value="brand.php?br=Canvas">Canvas</option>
			<option value="brand.php?br=Diesel">Diesel</option>
			<option value="brand.php?br=Dolce and Gabanna">Dolce & Gabanna</option>
			<option value="brand.php?br=Fred Perry">Fred Perry</option>
			<option value="brand.php?br=Gibson">Gibson</option>
			<option value="brand.php?br=Helly Hansen">Helly Hansen</option>
			<option value="brand.php?br=Kickers">Kickers</option>
			<option value="brand.php?br=Kidz and Co.">Kidz and Co.</option>
			<option value="brand.php?br=Lee">Lee</option>
			<option value="brand.php?br=Levis">Levis</option>
			<option value="brand.php?br=Mix">Mix</option>
			<option value="brand.php?br=Nene">Nene</option>
			<option value="brand.php?br=Nike">Nike</option>
			<option value="brand.php?br=Quiksilver">Quiksilver</option>
			<option value="brand.php?br=Rockport">Rockport</option>
			<option value="brand.php?br=Ted Baker">Ted Baker</option>
			<option value="brand.php?br=Tommy Hilfiger">Tommy Hilfiger</option>
			<option value="brand.php?br=Wrangler">Wrangler</option>
          </select>
        </form>
      </li> 
    </ul> 
    <h3 class="style2">Sort By Category</h3>
	<ul> 
      <li>
    <form name="form2" action="#">
      <select name="categorymenu" onChange="MM_jumpMenu('parent',this,0)">
	    <option value="#">Select Category</option>
        <option value="sortid.php">ID</option>
        <option value="sortprice.php">Price</option>
        <option value="sortbrand.php">Brand</option>
        <option value="sorttype.php">Type</option>
      </select>
    </form>
    </li>  
	</ul> 
    
<?php
// If user is logged in display username and 'Logout' link.
if ($_SESSION['username']!='') {
echo("<font size=2>"); 
echo("User: ");
echo $_SESSION['username'];
echo("<br><a href=logout.php>Logout</a></font>");
}
?>
</div> 
  <div class="style2" id="advert"> 
  <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
    <input type="hidden" name="cmd" value="_cart">
    <input type="hidden" name="display" value="1">
    <input type="hidden" name="bn" value="wa_dw_4.0.0">
    <input type="hidden" name="business" value="mzakariyah@hotmail.com">
    <input type="hidden" name="receiver_email" value="mzakariyah@hotmail.com">
    <input type="hidden" name="mrb" value="R-3WH47588B4505740X">
    <input type="image" name="submit" src="http://images.paypal.com/images/view_cart_02.gif" alt="Make payments with PayPal - it's fast, free and secure!">
  </form>
    <img src="paypal_logo.gif" alt="All payments in this website are made through PayPal." width="117" height="35"> This website uses the PayPal service.<br>
  </div> 
  <div class="style2" id="loginfo">
    <p></p>
  </div> 
</div> 
<span class="style2">
<!--end navbar --> 
</span>
<div class="style2" id="siteInfo">  
  <div align="left"><a href="about.php">About Us</a> | <a href="sitemap.php">Site
    Map</a> | <a href="privacypolicy.php">Privacy Policy</a> | <a href="contact.php">Contact Us</a> | <span class="style11"> 	&copy;2004 Shopoholic Online </span></div>
</div> 
<br> 
</body>
</html>
