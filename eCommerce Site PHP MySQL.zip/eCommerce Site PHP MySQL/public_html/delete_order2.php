<?php

include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Remove Order</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style7 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
.style8 {font-size: x-large}
-->
</style>
</head>
<h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style7">Shop-o-holic</span></h1>
<body>
<span class="style15 style8">Remove Order</span> <br>
<br>
<?php

// Posted order number from previous page.
$orderno = $_POST['orderno'];

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Define the query: Select all fields from table 'orders' with the order number defined above.
$sql="select * from orders where orderno=$orderno";
 
// Execute the query.
$rs2=mysql_query($sql,$conn) 
		or die("Could not execute query");

// Create another query: Delete the order with order number defined above from the database.
$sql="delete from orders where orderno=$orderno";
 
// Execute this query.
$rs=mysql_query($sql,$conn) 
		or die("Could not execute query");

// Display the order number that has been removed.
echo("Order Number $orderno has been removed from the database.");
?>

<br>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>