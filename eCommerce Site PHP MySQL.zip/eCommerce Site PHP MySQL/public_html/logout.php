<?php  
        include 'checklogin.php';
     
        // Destroy the session and redirect to the login page.
	session_destroy();
        header("Location: http://www.mcscw3.le.ac.uk/~mzh2/login_form.html"); 
?>
