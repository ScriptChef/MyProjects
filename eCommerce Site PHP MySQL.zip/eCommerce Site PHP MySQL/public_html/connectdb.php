<?php

// Make a connection with MySQL using server name, MySQL username and password defined below.
$conn=@mysql_pconnect("achilles", "mzh2","Ahcoh6ti") or die("Err:Conn");

// Select the specified database.
$rs = @mysql_select_db("mzh2", $conn) or die("Err:Db");

?>
