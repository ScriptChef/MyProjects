<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Update Item</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style7 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
.style8 {font-size: x-large}
-->
</style>
 
</head>
<h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style7">Shop-o-holic</span></h1>
<body>
<span class="style15 style8">Update Item</span> <br>
<br>
<?php

// Get edited item details from the page 'update_item.php'.
$id = $_POST['id'];
$newbrand = $_POST['newbrand'];
$newname = $_POST['newname'];
$newprice = $_POST['newprice'];
$newstocklevel = $_POST['newstocklevel'];
$newreorderquantity = $_POST['newreorderquantity'];
$newreorderlevel = $_POST['newreorderlevel'];
$newtype = $_POST['newtype'];
$newsize = $_POST['newsize'];
$newinfo = $_POST['newinfo'];

// Conenct to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Update Brand Field
$sql1="update item set brand=\"$newbrand\" where id=$id";

// Update Brand Field
$rs1=mysql_query($sql1,$conn);

// Update Name(Product Title) Field
$sql2="update item set name=\"$newname\" where id=$id";

// Update Name(Product Title) Field
$rs2=mysql_query($sql2,$conn);

// Update Price Field
$sql3="update item set price=$newprice where id=$id";

// Update Price Field
$rs3=mysql_query($sql3,$conn);

// Update Stock Level Field
$sql4="update item set stocklevel=newstocklevel where id=$id";

// Update Stock Level Field
$rs4=mysql_query($sql4,$conn);

// Update Reorder Quantity Field
$sql5="update item set reorderquantity=$newreorderquantity where id=$id";

// Update Reorder Quantity Field
$rs5=mysql_query($sql5,$conn);

// Update Reorder Level Field
$sql6="update item set reorderlevel=$newreorderlevel where id=$id";

// Update Reorder Level Field
$rs6=mysql_query($sql6,$conn);

// Update Size Field
$sql7="update item set size=\"$newsize\" where id=$id";

// Update Size Field
$rs7=mysql_query($sql7,$conn);

// Update Type Field
$sql8="update item set type='$newtype' where id=$id";

// Update Type Field
$rs8=mysql_query($sql8,$conn);

// Update Info Field
$sql9="update item set info=\"$newinfo\" where id=$id";

// Update Info Field
$rs9=mysql_query($sql9,$conn);

// Display modified item details.
echo("$id $newbrand $newname $newprice $newstocklevel $newreorderquantity $newreordelevel $newsize $newtype $newinfo");
?>

<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Admin Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>