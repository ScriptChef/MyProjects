<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - Remove Item</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style7 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
.style8 {font-size: x-large}
-->
</style>
</head>
<h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style7">Shop-o-holic</span></h1>
<body>
<span class="style15 style8">Remove Item</span> <br>
<br>
<?php

// Get item number entered by admin.
$itemno = $_POST['itemno'];

// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';

// Define the query: Get all info on this item.
$sql="select * from item where id=$itemno";
 
// Execute this query.
$rs2=mysql_query($sql,$conn) 
		or die("Could not execute query");

// Display item info.
while( $row = mysql_fetch_array($rs2) )
{
	$id=$row["id"]; 
	$brand=$row["brand"]; 
	$name=$row["name"]; 
	$price=$row["price"];

echo("<p> Brand: $brand<br>   Product Title: $name<br>  ID: $id<br>  Price: �$price </p>");
}

// Remove this item from the database.
$sql="delete from item where id=$itemno";
 
// Execute the query.
$rs=mysql_query($sql,$conn) 
		or die("Could not execute query");

// Display message, 'item now removed'.
echo("<br>The item above with ID:$id has now been removed from the database.");

?>
<br>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>