<?
session_start(); // Start the session.

// Display successful login message, and give user options in the form of links.
echo "<font face=Verdana, Arial, Helvetica, sans-serif> Welcome ". $_SESSION['first_name'] ." ". 
$_SESSION['last_name'] .". You have successfully logged in.</font><br /><br />";
echo("<font face=Verdana, Arial, Helvetica, sans-serif>What do you want to do?</font>");
echo "<p> <a href=index.php><font face=Verdana, Arial, Helvetica, sans-serif>Enter Website</font></a></p>";
echo "<p> <a href=userpage.php><font face=Verdana, Arial, Helvetica, sans-serif>My Account</font></a></p>";
echo "<p> <a href=logout.php><font face=Verdana, Arial, Helvetica, sans-serif>Logout</font></a></p>";
?>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">