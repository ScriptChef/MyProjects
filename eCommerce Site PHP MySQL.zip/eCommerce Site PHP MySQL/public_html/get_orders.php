<?php
include 'adminchecklogin.php';
// ACCESS RESTRICTION
// Check if administrator is logged in, else redirect to the admin log-in page.
  if ($_SESSION['admin']=='') {
	#redirect the browser - not in book
	header("Location: http://www.mcscw3.le.ac.uk/~mzh2/adminlogin_form.html");  
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Shopoholic - View Orders</title>
<link rel="stylesheet" href="2col_leftNav.css" type="text/css">
<style type="text/css">
<!--
.style2 {font-family: Verdana, Arial, Helvetica, sans-serif}
h1,h2,h3,h4,h5,h6 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.style15 {font-size: x-large}
.style16 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: x-large;
	color: #FFFFFF;
}
-->
</style>
</head>
<body> 
 <h1 class="style20" id="siteName" align="center"><span class="gloss2 style10 style11 style16">Shop-o-holic</span></h1>
  
   <span class="style15">View Orders</span> <br>
  <br>

<?php
  
// Connect to the database using the file 'connectdb.php'.
include 'connectdb.php';
 
// Define the query: Get all the orders from the 'orders' table.
$sql="select * from orders";
 
// Execute the above query.
$rs=mysql_query($sql,$conn) 
		or die("Could not execute query");

// Write all the orders into a table
$list = "<table border=\"1\" cellpadding=\"2\">";
$list.="<tr><th>Order No.</th>";
$list.="<th>UserID</th>";
$list.="<th>Item</th>";
$list.="<th>Name</th>";
$list.="<th>Username</th>";
$list.="<th>Email</th>";
$list.="<th>Address</th>";

// While there are more orders to get, display an order.
while($row= mysql_fetch_array($rs) )
{
   $list .= "<tr>";
   $list .= "<td>".$row["orderno"]."</td>";
   $list .= "<td>".$row["userid"]."</td>";
   $list .= "<td>".$row["item"]."</td>";
   $list .= "<td>".$row["first_name"]." ".$row["last_name"]."</td>";
   $list .= "<td>".$row["username"]."</td>";
   $list .= "<td>".$row["email"]."</td>";
   $list .= "<td>".$row["address"]."</td>";
   $list .= "</tr>";
}
$list .= "</table>";
echo($list);
?>
<p> <a href="admin.php"><font face=Verdana, Arial, Helvetica, sans-serif> Home </font></a><br>
<a href="adminlogout.php"><font face=Verdana, Arial, Helvetica, sans-serif> Logout </font></a></p>
</body>
</html>
